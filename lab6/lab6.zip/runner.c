#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include"list.h"

node* create_list(char*);

int main(int argc, char* argv[])
{
	node* create1= NULL;
	if (argc!=2){
		printf("Not Enough inputs");
		return 0;
	}
	create1=create_list(argv[1]);
	print_list(create1);
	free_list(create1);
	return 0;

}

node* create_list(char* filename)
{
	int i=0;
	int temp;
	node* ins=NULL;
	FILE* file=fopen(filename,"r");
	if(file==NULL){
		return 0;
	}
	while(!feof(file))
	{
		fscanf(file,"%d",&temp);
		ins=insert_at_head(ins,temp);
	}
	return ins;
}

